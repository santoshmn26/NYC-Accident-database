# -*- coding: utf-8 -*-
#!/usr/bin/env python
#importing system modules
import sys
import folium
import csv
f= open("/home/santu/Python/Outputs/Locations/Locations.csv","r+")
reader = csv.reader(f)
your_list = list(reader)
x1=[] # a list to store all the locations of the accidents 
i=0
mapit = folium.Map( location=[40.6960346,-73.9845292], zoom_start=6 )
for coord in your_list:
	folium.Marker( location=[ float(coord[0]), float(coord[1]) ]).add_to( mapit )
	mapit.save( '/home/santu/Python/map1.html')
	i+=1
	if(i==15):
		break
